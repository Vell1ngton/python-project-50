### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vell1ngton/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vell1ngton/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/ccc4e2c28e12d4c50691/maintainability)](https://codeclimate.com/github/Vell1ngton/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/ccc4e2c28e12d4c50691/test_coverage)](https://codeclimate.com/github/Vell1ngton/python-project-50/test_coverage)


GENDIFF MODULE
<a href="https://asciinema.org/a/TBcVp98Nbg1gg0hX3JPDNsHgh" target="_blank"><img src="https://asciinema.org/a/TBcVp98Nbg1gg0hX3JPDNsHgh.svg" /></a>