### Hexlet tests and linter status:
[![Actions Status](https://github.com/Vell1ngton/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Vell1ngton/python-project-50/actions)


GENDIFF MODULE
<a href="https://asciinema.org/a/TBcVp98Nbg1gg0hX3JPDNsHgh" target="_blank"><img src="https://asciinema.org/a/TBcVp98Nbg1gg0hX3JPDNsHgh.svg" /></a>